# TV Ana Ekran (Kotlin, bağımlılıksız)
- Büyük saat + İstanbul hava durumu (Open-Meteo, API anahtarı yok, 30 dk'da bir yenilenir)
- Uygulama ızgarası, favoriler (★), gizli uygulamalar
- Bir uygulamada OK tuşuna uzun bas (veya MENU) -> aç / favori / gizle / uygulama bilgisi
- Şehir değiştirmek için MainActivity.kt başındaki CITY, LAT, LON sabitleri

## APK üretme
Android Studio: klasörü aç -> Build > Build APK(s)
GitHub: projeyi yükle -> Actions > Build APK > Run workflow -> artifact: app-debug

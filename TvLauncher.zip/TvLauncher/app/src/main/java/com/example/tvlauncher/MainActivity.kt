package com.example.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        const val CITY = "İstanbul"
        const val LAT = 41.0082
        const val LON = 28.9784
        const val REFRESH_MS = 30 * 60 * 1000L
    }

    private data class AppItem(
        val label: String,
        val pkg: String,
        val component: ComponentName,
        val icon: Drawable
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var grid: GridView
    private lateinit var tvWeather: TextView
    private lateinit var tvCity: TextView
    private lateinit var btnHidden: Button

    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var showHidden = false
    private var apps: List<AppItem> = emptyList()
    private var visible: List<AppItem> = emptyList()
    private val adapter = AppAdapter()

    private val weatherTask = object : Runnable {
        override fun run() {
            fetchWeather()
            handler.postDelayed(this, REFRESH_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)

        grid = findViewById(R.id.grid)
        tvWeather = findViewById(R.id.weather)
        tvCity = findViewById(R.id.city)
        btnHidden = findViewById(R.id.btnHidden)

        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> launch(visible[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            showMenu(visible[pos])
            true
        }
        btnHidden.setOnClickListener {
            showHidden = !showHidden
            refreshList()
        }

        tvCity.text = CITY
        if (prefs.contains("w_temp")) {
            showWeather(prefs.getInt("w_temp", 0), prefs.getInt("w_code", 0))
        }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        refreshList()
        handler.removeCallbacks(weatherTask)
        handler.post(weatherTask)
        grid.requestFocus()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(weatherTask)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Ana ekranda geri tuşu bir şey yapmaz
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            val p = grid.selectedItemPosition
            if (p in visible.indices) {
                showMenu(visible[p])
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- Uygulama listesi ----------

    private fun loadApps() {
        val pm = packageManager
        val seen = HashSet<String>()
        val list = ArrayList<AppItem>()
        for (cat in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val ai = ri.activityInfo
                if (ai.packageName == packageName) continue
                if (!seen.add(ai.packageName)) continue
                list.add(
                    AppItem(
                        ri.loadLabel(pm).toString(),
                        ai.packageName,
                        ComponentName(ai.packageName, ai.name),
                        ri.loadIcon(pm)
                    )
                )
            }
        }
        apps = list
    }

    private fun favSet(): Set<String> = prefs.getStringSet("fav", emptySet()) ?: emptySet()
    private fun hiddenSet(): Set<String> = prefs.getStringSet("hidden", emptySet()) ?: emptySet()

    private fun refreshList() {
        val fav = favSet()
        val hidden = hiddenSet()
        visible = apps
            .filter { showHidden || it.pkg !in hidden }
            .sortedWith(compareBy({ it.pkg !in fav }, { it.label.lowercase() }))
        adapter.notifyDataSetChanged()
        btnHidden.text = if (showHidden) "Gizlileri sakla" else "Gizli uygulamalar (${hidden.size})"
    }

    private fun toggle(key: String, pkg: String) {
        val s = HashSet<String>(prefs.getStringSet(key, emptySet()) ?: emptySet())
        if (!s.add(pkg)) s.remove(pkg)
        prefs.edit().putStringSet(key, s).apply()
        refreshList()
    }

    private fun launch(item: AppItem) {
        val pm = packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(item.pkg)
            ?: pm.getLaunchIntentForPackage(item.pkg)
        if (intent == null) {
            Toast.makeText(this, "Uygulama açılamadı", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Uygulama açılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMenu(item: AppItem) {
        val isFav = item.pkg in favSet()
        val isHidden = item.pkg in hiddenSet()
        val opts = arrayOf(
            "Aç",
            if (isFav) "Favorilerden çıkar" else "Favorilere ekle",
            if (isHidden) "Göster" else "Gizle",
            "Uygulama bilgisi"
        )
        AlertDialog.Builder(this)
            .setTitle(item.label)
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> launch(item)
                    1 -> toggle("fav", item.pkg)
                    2 -> toggle("hidden", item.pkg)
                    3 -> try {
                        startActivity(
                            Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:${item.pkg}")
                            )
                        )
                    } catch (e: Exception) {
                        Toast.makeText(this, "Ayarlar açılamadı", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    // ---------- Hava durumu (Open-Meteo) ----------

    private fun fetchWeather() {
        executor.execute {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON" +
                        "&current=temperature_2m,weather_code&timezone=auto"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val cur = JSONObject(body).getJSONObject("current")
                val temp = Math.round(cur.getDouble("temperature_2m")).toInt()
                val code = cur.getInt("weather_code")
                prefs.edit().putInt("w_temp", temp).putInt("w_code", code).apply()
                handler.post { showWeather(temp, code) }
            } catch (e: Exception) {
                // Hata olursa önbellekteki değer görünmeye devam eder
            }
        }
    }

    private fun showWeather(temp: Int, code: Int) {
        val (emoji, desc) = describe(code)
        tvWeather.text = "$emoji $temp°"
        tvCity.text = if (desc.isEmpty()) CITY else "$CITY · $desc"
    }

    private fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Açık"
        1, 2 -> "🌤️" to "Az bulutlu"
        3 -> "☁️" to "Bulutlu"
        45, 48 -> "🌫️" to "Sisli"
        in 51..57 -> "🌦️" to "Çiseleme"
        in 61..67 -> "🌧️" to "Yağmurlu"
        in 71..77 -> "❄️" to "Karlı"
        in 80..82 -> "🌧️" to "Sağanak"
        85, 86 -> "❄️" to "Kar sağanağı"
        in 95..99 -> "⛈️" to "Fırtına"
        else -> "🌡️" to ""
    }

    // ---------- Adapter ----------

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = visible.size
        override fun getItem(position: Int): Any = visible[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_app, parent, false)
            val app = visible[position]
            v.findViewById<ImageView>(R.id.icon).setImageDrawable(app.icon)
            val prefix = when {
                app.pkg in hiddenSet() -> "🙈 "
                app.pkg in favSet() -> "★ "
                else -> ""
            }
            v.findViewById<TextView>(R.id.label).text = prefix + app.label
            return v
        }
    }
}
